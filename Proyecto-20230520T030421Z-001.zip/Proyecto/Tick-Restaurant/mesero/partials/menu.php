<html>
    <head>
        <meta charset="UTF-8">
        <title>Sesión de administrador</title>
        <link rel="stylesheet" href="../admin.css">
    </head>
    <body>
        <!---Menu section starts-->
        <div class="menu text-center clearfix">
            <div class="envoltura">
                <h3 class="titulo">Tick-Restaurant</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                </ul>
            </div>
        </div>
        <!---Menu section ends-->