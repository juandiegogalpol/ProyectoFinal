<?php include('partials/menu.php'); ?>
    <div class="main-content">
        <div class="envoltura">
            <h3>Ordenes activas</h3>
            <!---Aquí se imprime la lista de ordenes. Cada mesa se separa en el div "empleado-data text-center"-->
            <div class="empleado-data text-center">
                <h3>Orden de mesa 1.</h3><br>
                2 Tacos de Bisteck.<br>
                2 Tacos de Pastor.<br>
            </div>
            <div class="empleado-data text-center">
                <h3>Orden de mesa 2.</h3><br>
                5 Tacos de Pastor.
            </div>
            <div class="empleado-data text-center">
                <h3>Orden de mesa 3.</h3><br>
                2 Tortas Ahogadas.
            </div>
        </div>
    </div>
<?php include('partials/footer.php'); ?>