        <!---Footer section starts-->
        <div class="footer">
            <div class="envoltura">
                <p class="text-center">© 2021 Tick-Restaurant.  All rights reserved.</p>
            </div>
        </div>
        <!---Footer section ends-->
    </body>
</html>