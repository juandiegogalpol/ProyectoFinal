<html>
    <head>
        <meta charset="UTF-8">
        <title>Sesión de administrador</title>
        <link rel="stylesheet" href="../admin.css">
    </head>
    <body>
        <!---Menu section starts-->
        <div class="menu text-center clearfix">
            <div class="envoltura">
                <h3 class="titulo">Tick-Restaurant</h3>
                <ul>
                    <li><a href="añadir_mesa_admin.php">Añadir mesa</a></li>
                    <li><a href="añadir_empleado_admin.php">Añadir empleados</a></li>
                    <li><a href="gestion_meseros_admin.php">Gestionar meseros</a></li>
                    <li><a href="gestion_platillos_admin.php">Gestionar platillos</a></li>
                </ul>
            </div>
        </div>
        <!---Menu section ends-->