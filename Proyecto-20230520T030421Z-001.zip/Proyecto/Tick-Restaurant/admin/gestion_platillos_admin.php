<?php include('partials/menu.php'); ?>
        <!---Main content section starts-->
        <div class="main-content">
            <div class="envoltura">
                Gestión de platillos.
            </div>
        </div>
        <!---Main content section ends-->
<?php include('partials/footer.php'); ?>