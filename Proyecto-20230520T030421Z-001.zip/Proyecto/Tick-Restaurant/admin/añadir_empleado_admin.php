<?php include('partials/menu.php'); ?>
        <!---Main content section starts-->
        <div class="main-content">
            <div class="envoltura">
                Añadir empleado.
            </div>
        </div>
        <!---Main content section ends-->
<?php include('partials/footer.php'); ?>