<?php include('partials/menu.php'); ?>
        <!---Main content section starts-->
        <div class="main-content">
            <ul>
                <li>
                    <div class="envoltura">
                        <strong>CARGO</strong>
                        <div class="empleado-data">
                            <h4>Nombre</h4><br/>
                            Resto de información.<br/>
                            <a href="añadir_empleado_admin.html"><button class="boton_navegar">Editar</button></a>
                        </div>
                    </div> 
                </li>
                <li> 
                    <div class="envoltura">
                        <strong>CARGO</strong>
                        <div class="empleado-data">
                            <h4>Nombre</h4><br/>
                            Resto de información.<br/>
                            <a href="añadir_empleado_admin.html"><button class="boton_navegar">Editar</button></a>
                        </div>
                    </div>        
                </li>
            </ul>
        </div>
        <!---Main content section ends-->
<?php include('partials/footer.php'); ?>